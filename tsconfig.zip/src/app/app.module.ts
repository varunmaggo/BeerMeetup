import { BrowserModule } from '@angular/platform-browser';  
import { NgModule } from '@angular/core';  
import { FormsModule } from '@angular/forms';  
import { HttpClientModule } from '@angular/common/http';  

import { AppComponent } from './app.component';
import { BeerMeetupService } from './beermeetup.service';  
import { BeerMeetupComponent } from './beermeetup.component';  
@NgModule({
  declarations: [
    AppComponent,
    BeerMeetupComponent  
  ],
  imports: [
    BrowserModule,  
    FormsModule,  
    HttpClientModule  
  ],
  providers: [BeerMeetupService],  
  bootstrap: [AppComponent]  
})
export class AppModule { }
