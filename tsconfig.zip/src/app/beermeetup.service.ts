import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';  
  
import { BeerMeetup } from './beermeetup';  
  
const api = 'http://localhost:53090/api';  
  
@Injectable()  
export class BeerMeetupService {  
  constructor(private http: HttpClient) { }  
  
  getBM() {  
    return this.http.get<Array<BeerMeetup>>(`${api}/beermeetup`);  
  }  
  
  deleteBM(beermeetup: BeerMeetup) {  
    return this.http.delete(`${api}/beermeetup?uid=${beermeetup.uid}`);  
  }  
  
  addBM(beermeetup: BeerMeetup) {  
    return this.http.post<BeerMeetup>(`${api}/beermeetup/`, beermeetup);  
  }  
  
  updateBM(beermeetup: BeerMeetup) {  
    return this.http.put<BeerMeetup>(`${api}/beermeetup?uid=${beermeetup.uid}`, beermeetup);  
  }  
}