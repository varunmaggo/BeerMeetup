import { Component, OnInit } from '@angular/core';  
  
import { BeerMeetup } from './beermeetup';  
import { BeerMeetupService } from './beermeetup.service';  
  
@Component({  
  selector: 'app-heroes',  
  templateUrl: './beermeetup.component.html'  
})  
export class BeerMeetupComponent implements OnInit {  
  addingBM = false;  
  deleteButtonSelected = false;  
  heroes: any = [];  
  selectedBM: BeerMeetup;  
  
  constructor(private beermeetupService: BeerMeetupService) { }  
  
  ngOnInit() {  
    this.getBM();  
  }  
  
  cancel() {  
    this.addingBM = false;  
    this.selectedBM = null;  
  }  
  
  deleteBM(hero: BeerMeetup) {  
    this.deleteButtonSelected = true;  
    let value: boolean;  
    value = confirm("Are you sure want to delete this meetup?");  
    if (value != true) {  
      return;  
    }  
    this.beermeetupService.deleteBM(hero).subscribe(res => {  
      this.heroes = this.heroes.filter(h => h !== hero);  
      if (this.selectedBM === hero) {  
        this.selectedBM = null;  
      }  
    });  
  }  
  
  getBM() {  
    return this.beermeetupService.getBM().subscribe(heroes => {  
      this.heroes = heroes;  
    });  
  }  
  
  enableAddMode() {  
    this.addingBM = true;  
    this.selectedBM = new BeerMeetup();  
  }  
  
  onSelect(hero: BeerMeetup) {  
    if (this.deleteButtonSelected == false) {  
      this.addingBM = false;  
      this.selectedBM = hero;  
    }  
    this.deleteButtonSelected = false;  
  }  
  
  save() {  
    if (this.addingBM) {  
      this.beermeetupService.addBM(this.selectedBM).subscribe(hero => {  
        this.addingBM = false;  
        this.selectedBM = null;  
        this.heroes.push(hero);  
      });  
    } else {  
      this.beermeetupService.updateBM(this.selectedBM).subscribe(hero => {  
        this.addingBM = false;  
        this.selectedBM = null;  
      });  
    }  
  }  
}