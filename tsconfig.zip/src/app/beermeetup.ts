export class BeerMeetup {  
    uid: string;  
    location: string;  
    brand: string;  
    cheers: string;  
}